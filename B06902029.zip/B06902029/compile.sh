#!/bin/bash
# Put your commands below (can be multiple lines) to compile your program.
# Here's an example which will compile all the .c files in current directory with gcc:

echo "Nothing todo..."

